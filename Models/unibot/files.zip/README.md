# 🎓 UniBot — University RAG Chatbot

A full-stack intelligent university assistant with PDF knowledge base, voice input/output, scholarship calculator, and lead capture.

---

## ✨ Features

| Feature | Description |
|---|---|
| 🧠 RAG Chatbot | Answers from your university PDFs via Pinecone + OpenAI |
| 🎙️ Voice I/O | Mic input via Web Speech API + TTS output |
| 🏆 Scholarship Calculator | Admin-configurable FSc/degree-based calculator |
| 📋 Lead Capture | Collects name, phone, email, address automatically |
| ⚙️ Admin Panel | Set scholarship tiers & annual fee before deploying |
| 📄 PDF Ingestion | Upload any PDF → embedded into Pinecone |

---

## 🚀 Quick Start

### 1. Clone & Install

```bash
# Install dependencies
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env and add your keys:
#   OPENAI_API_KEY=sk-...
#   PINECONE_API_KEY=...
#   PINECONE_INDEX_NAME=university-chatbot
```

### 3. Ingest Your University PDFs

```bash
# Start the server first
uvicorn main:app --reload

# In another terminal, upload your PDF:
curl -X POST "http://localhost:8000/ingest-pdf" \
  -F "file=@/path/to/university-prospectus.pdf"

# Or via browser: POST /ingest-pdf with multipart form
```

### 4. Run the Server

```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

Open `http://localhost:8000` in your browser.

---

## 🔑 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/` | Chat UI frontend |
| `POST` | `/chat` | Send message, get AI reply |
| `POST` | `/ingest-pdf` | Upload & embed a PDF |
| `POST` | `/calculate-scholarship` | Calculate scholarship |
| `GET` | `/scholarship-config` | Get current scholarship config |
| `PUT` | `/scholarship-config` | Update scholarship config (admin) |
| `POST` | `/capture-lead` | Save student lead manually |
| `GET` | `/leads` | View all captured leads |

---

## ⚙️ Admin: Scholarship Configuration

Click the ⚙️ button in the sidebar to configure:

- **FSc Tiers**: Set percentage ranges and corresponding scholarship %
- **Degree Bonus**: Extra % for Gold Medal / Distinction
- **Annual Fee**: Base fee amount in PKR (or any currency)

Changes take effect immediately and persist via the `/scholarship-config` endpoint.

**Default tiers:**
| FSc % | Scholarship |
|---|---|
| 90–100% | 100% (Full) |
| 80–89% | 75% |
| 70–79% | 50% |
| 60–69% | 25% |
| Below 60% | None |

**Degree bonus:**
- Gold Medal: +10%
- Distinction: +5%
- First Division: +0%

---

## 🎙️ Voice Usage

1. Click the 🎙️ mic button to start recording
2. Speak your question
3. Bot automatically responds and **reads the answer aloud** via TTS
4. Works best in Chrome/Edge

---

## 📋 Lead Capture

Leads are captured **two ways**:
1. **Automatically** — bot extracts name, phone, email from chat conversation
2. **Manually** — via the "Register" tab form in the sidebar

View all leads at `GET /leads`.

---

## 🏗️ Architecture

```
Browser (index.html)
    │
    ├── /chat ──────────────► main.py (FastAPI)
    │                              │
    │                              ├── Pinecone (vector search)
    │                              ├── OpenAI Embeddings
    │                              └── GPT-4o (LLM)
    │
    ├── /ingest-pdf ────────► PDF → chunks → Pinecone
    ├── /calculate-scholarship
    ├── /capture-lead
    └── /scholarship-config
```

---

## 🔒 Production Notes

- Add authentication to `/leads` and `/scholarship-config` endpoints
- Use a database (PostgreSQL) instead of in-memory `leads` dict
- Set `allow_origins` to your specific domain in CORS config
- Use environment-specific Pinecone indexes (dev/prod)
