import os
import json
import re
from typing import Optional, List
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from dotenv import load_dotenv

from pinecone import Pinecone, ServerlessSpec
from langchain_pinecone import PineconeVectorStore
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter

load_dotenv()

# ─────────────────────────────────────────
# Config (Admin-configurable scholarship values)
# ─────────────────────────────────────────

SCHOLARSHIP_CONFIG = {
    "fsc_thresholds": [
        {"min": 90, "max": 100, "percentage": 100, "label": "Full Scholarship"},
        {"min": 80, "max": 89.99, "percentage": 75,  "label": "75% Scholarship"},
        {"min": 70, "max": 79.99, "percentage": 50,  "label": "50% Scholarship"},
        {"min": 60, "max": 69.99, "percentage": 25,  "label": "25% Scholarship"},
        {"min": 0,  "max": 59.99, "percentage": 0,   "label": "No Scholarship"},
    ],
    "previous_degree_bonus": {
        "gold_medal":    10,
        "distinction":    5,
        "first_division": 0,
    },
    "annual_fee": 120000,
    "currency": "PKR",
}

# ─────────────────────────────────────────
# Models
# ─────────────────────────────────────────

class ChatRequest(BaseModel):
    session_id: str
    message: str

class LeadInfo(BaseModel):
    session_id: str
    name: Optional[str] = None
    address: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None

class ScholarshipRequest(BaseModel):
    fsc_percentage: float
    previous_degree_grade: Optional[str] = "first_division"  # gold_medal | distinction | first_division

class ScholarshipConfigUpdate(BaseModel):
    fsc_thresholds: list
    previous_degree_bonus: dict
    annual_fee: float
    currency: str

class IngestRequest(BaseModel):
    pdf_path: str  # server-side path to PDF

# ─────────────────────────────────────────
# AI + Vector Store Init
# ─────────────────────────────────────────

pc = Pinecone(api_key=os.environ.get("PINECONE_API_KEY"))
index_name = os.environ.get("PINECONE_INDEX_NAME", "university-chatbot")

# Create index if not exists
existing = [i.name for i in pc.list_indexes()]
if index_name not in existing:
    pc.create_index(
        name=index_name,
        dimension=3072,
        metric="cosine",
        spec=ServerlessSpec(cloud="aws", region="us-east-1"),
    )

index = pc.Index(index_name)

embeddings = OpenAIEmbeddings(
    model="text-embedding-3-large",
    api_key=os.environ.get("OPENAI_API_KEY"),
)
vector_store = PineconeVectorStore(index=index, embedding=embeddings)
llm = ChatOpenAI(model="gpt-4o", temperature=0.5, api_key=os.environ.get("OPENAI_API_KEY"))

UNIVERSITY_SYSTEM_PROMPT = """You are an expert university admissions and information assistant for a university.
You help students with:
- Admission requirements, especially BS Computer Science minimum criteria
- Fee structures, scholarships, and financial aid
- Campus life, departments, and programs
- Application procedures and deadlines
- General university information

Always be helpful, accurate, and encouraging. Use the provided context from university documents.
If asked about BS CS admission, always mention the minimum criteria clearly.
When capturing student leads, collect: name, phone, address naturally in conversation.
Respond in a warm, professional, and encouraging tone.
If the context does not contain an answer, say so honestly."""

# In-memory session store
sessions: dict = {}
leads: dict = {}

# ─────────────────────────────────────────
# App
# ─────────────────────────────────────────

app = FastAPI(title="University RAG Chatbot", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─────────────────────────────────────────
# PDF Ingestion
# ─────────────────────────────────────────

@app.post("/ingest-pdf")
async def ingest_pdf(file: UploadFile = File(...)):
    """Upload and embed a PDF into Pinecone."""
    import tempfile, shutil
    suffix = ".pdf"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        shutil.copyfileobj(file.file, tmp)
        tmp_path = tmp.name

    loader = PyPDFLoader(tmp_path)
    docs = loader.load()

    splitter = RecursiveCharacterTextSplitter(chunk_size=800, chunk_overlap=100)
    chunks = splitter.split_documents(docs)

    vector_store.add_documents(chunks)
    os.unlink(tmp_path)

    return {"message": f"Ingested {len(chunks)} chunks from '{file.filename}'"}

# ─────────────────────────────────────────
# Scholarship Calculator
# ─────────────────────────────────────────

@app.post("/calculate-scholarship")
async def calculate_scholarship(req: ScholarshipRequest):
    pct = req.fsc_percentage
    grade = req.previous_degree_grade or "first_division"

    base = 0
    label = "No Scholarship"
    for tier in SCHOLARSHIP_CONFIG["fsc_thresholds"]:
        if tier["min"] <= pct <= tier["max"]:
            base = tier["percentage"]
            label = tier["label"]
            break

    bonus = SCHOLARSHIP_CONFIG["previous_degree_bonus"].get(grade, 0)
    total_pct = min(base + bonus, 100)
    fee = SCHOLARSHIP_CONFIG["annual_fee"]
    discount = fee * total_pct / 100
    payable = fee - discount

    return {
        "fsc_percentage": pct,
        "previous_degree_grade": grade,
        "base_scholarship_pct": base,
        "bonus_pct": bonus,
        "total_scholarship_pct": total_pct,
        "label": label,
        "annual_fee": fee,
        "discount_amount": discount,
        "payable_amount": payable,
        "currency": SCHOLARSHIP_CONFIG["currency"],
    }

@app.get("/scholarship-config")
async def get_scholarship_config():
    return SCHOLARSHIP_CONFIG

@app.put("/scholarship-config")
async def update_scholarship_config(config: ScholarshipConfigUpdate):
    global SCHOLARSHIP_CONFIG
    SCHOLARSHIP_CONFIG.update(config.dict())
    return {"message": "Scholarship configuration updated.", "config": SCHOLARSHIP_CONFIG}

# ─────────────────────────────────────────
# Lead Management
# ─────────────────────────────────────────

@app.post("/capture-lead")
async def capture_lead(lead: LeadInfo):
    leads[lead.session_id] = lead.dict()
    return {"message": "Lead captured successfully.", "lead": lead.dict()}

@app.get("/leads")
async def get_leads():
    return {"leads": list(leads.values()), "total": len(leads)}

# ─────────────────────────────────────────
# Chat
# ─────────────────────────────────────────

def _detect_lead_info(message: str, session_id: str):
    """Try to extract name/phone/address from message."""
    lead = leads.get(session_id, {"session_id": session_id})
    phone_match = re.search(r'\b0\d{10}\b|\b\+92\d{10}\b|\b\d{11}\b', message)
    if phone_match and not lead.get("phone"):
        lead["phone"] = phone_match.group()
    if not lead.get("name"):
        name_match = re.search(r'(?:my name is|i am|i\'m)\s+([A-Z][a-z]+(?: [A-Z][a-z]+)*)', message, re.I)
        if name_match:
            lead["name"] = name_match.group(1).title()
    if not lead.get("email"):
        email_match = re.search(r'[\w.+-]+@[\w-]+\.\w+', message)
        if email_match:
            lead["email"] = email_match.group()
    if lead != {"session_id": session_id}:
        leads[session_id] = lead
    return lead

@app.post("/chat")
async def chat(req: ChatRequest):
    session_id = req.session_id
    user_msg = req.message.strip()

    if session_id not in sessions:
        sessions[session_id] = []

    history = sessions[session_id]

    # Detect lead info passively
    _detect_lead_info(user_msg, session_id)

    # Retrieve context from Pinecone
    try:
        docs = vector_store.similarity_search(user_msg, k=4)
        context = "\n\n".join([d.page_content for d in docs])
    except Exception:
        context = ""

    context_block = f"\n\n--- University Document Context ---\n{context}\n---\n" if context else ""

    messages = [SystemMessage(content=UNIVERSITY_SYSTEM_PROMPT + context_block)]
    for turn in history[-10:]:
        if turn["role"] == "user":
            messages.append(HumanMessage(content=turn["content"]))
        else:
            messages.append(AIMessage(content=turn["content"]))
    messages.append(HumanMessage(content=user_msg))

    response = llm.invoke(messages)
    reply = response.content

    history.append({"role": "user", "content": user_msg})
    history.append({"role": "assistant", "content": reply})
    sessions[session_id] = history

    return {
        "reply": reply,
        "session_id": session_id,
        "lead_captured": leads.get(session_id, {}),
    }

@app.get("/chat-history/{session_id}")
async def get_chat_history(session_id: str):
    return {"history": sessions.get(session_id, [])}

# ─────────────────────────────────────────
# Frontend
# ─────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def serve_frontend():
    with open("index.html", "r") as f:
        return f.read()

@app.get("/health")
async def health():
    return {"status": "ok"}
